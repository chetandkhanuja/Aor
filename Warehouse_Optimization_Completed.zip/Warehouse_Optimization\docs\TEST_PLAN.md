# Test Plan and Results

## 1. Test objectives

Verify dataset integrity, order feasibility, policy-route geometry, MIP route
feasibility/optimal status, and that policy plans are comparable to the MIP
benchmark. Automated tests are in `tests/test_optimizer.py`.

## 2. Test cases

| ID | Input / action | Expected result |
|---|---|---|
| TC-01 | Load packaged inputs | 100 warehouse locations; 101-by-101 symmetric distance matrix with zero diagonal; two orders |
| TC-02 | Run each policy for `ORD001` and `ORD002` | Complete pick coverage, no duplicated visit stops, orthogonal path, path length equals displayed distance |
| TC-03 | Solve MIP for each sample order | HiGHS proves optimality; selected locations cover all SKUs; route starts/ends at depot |
| TC-04 | Compare MIP and all policies for each order | All strategies present; MIP distance is no greater than policy distances |
| TC-05 | Change an order demand beyond every single-location stock quantity | Clear insufficient-stock error; no route returned |
| TC-06 | Largest Gap route has no rear-side picks | Route avoids an unnecessary rear-aisle traversal |
| TC-07 | Start Streamlit app and select each order/strategy | Browser displays comparison, pick list, route, selected locations, and distance |

## 3. Execution

From the `Warehouse_Optimization` directory:

```powershell
python -m pytest
python -m streamlit run app.py
```

The first command validates TC-01 through TC-06. TC-07 is an interactive
smoke-test and is validated with Streamlit `AppTest`.

## 4. Results

Automated tests ran successfully on 2026-11-13 with Python 3.14.7, Pyomo 6.10.1,
HiGHS 1.16.0, and Streamlit 1.65.0. `python -m pytest -q` reported 13 passed.
The Streamlit `AppTest` smoke test rendered both orders and the Largest Gap
selection without exceptions; the local app endpoint returned HTTP 200.

| Order | MIP benchmark | Return | Traversal | Largest Gap |
|---|---:|---:|---:|---:|
| ORD001 | 46.0 | 60.0 | 64.0 | 66.0 |
| ORD002 | 46.0 | 62.0 | 58.0 | 72.0 |

Distances are abstract layout units. These are outputs from the supplied
synthetic dataset and current implementation, not values from the research
paper.

## 5. Known limits / future tests

The current suite does not certify performance on large orders, split picking,
duplicate demand edge cases at the UI boundary, live inventory changes, or
hosted deployment. Add these before any operational use.
