# Software Requirements Specification (SRS)

## 1. System overview

The local Streamlit app is a single-user demonstration. It reads the packaged
CSV datasets, computes one order's benchmark and heuristic plans, and shows a
route comparison and warehouse diagram.

## 2. Functional requirements

| ID | Requirement | Acceptance check |
|---|---|---|
| FR-01 | List and accept a supported order ID. | Select `ORD001` and `ORD002` in the UI. |
| FR-02 | Aggregate demand by SKU and find locations with sufficient stock. | Every selected location has stock at least equal to demand. |
| FR-03 | Solve an assignment-and-routing MIP for the selected order. | HiGHS returns `optimal`; route starts/ends at DEPOT. |
| FR-04 | Produce Return, Traversal, and Largest Gap policy plans. | Each route covers the selected locations and has orthogonal path geometry. |
| FR-05 | Show distance, gap to MIP, selected locations, and visit sequence. | Compare table and pick list are visible in the app. |
| FR-06 | Visualize aisle layout, depot, route, and selected picks. | Strategy selection changes the route and selected markers. |
| FR-07 | Report invalid or infeasible inputs explicitly. | Unknown order, missing stock, and malformed datasets raise a clear error. |

## 3. Data requirements

| Dataset | Required fields / shape | Source |
|---|---|---|
| Orders | `order_id`, `sku_id`, positive `demand_qty` | `data/orders.csv` |
| Inventory | `sku_id`, `location_id`, non-negative `available_qty` | `data/inventory.csv` |
| Warehouse | 100 `location_id` values with aisle, position, x, and y | `phase2/data/warehouse.csv` |
| Distance matrix | 101 labeled rows and columns (100 locations and DEPOT), symmetric, zero diagonal | `data/distance_matrix.csv` |

Every order SKU must occur in inventory; every inventory location must be in the
warehouse and in the distance matrix. Duplicate SKU/location inventory rows,
negative quantities, non-positive order demand, and invalid distances are
rejected.

## 4. Model requirements

### Objective

Minimize the total distance of a single depot-to-depot tour, with the selected
storage locations chosen jointly with the route.

### Variables

| Variable | Domain | Meaning |
|---|---|---|
| \(x_{sl}\) | Binary | SKU \(s\) is assigned to location \(l\) |
| \(z_l\) | Binary | Location \(l\) is visited |
| \(y_{ij}\) | Binary | Route traverses arc \(i\rightarrow j\) |
| \(u_l\) | Integer | MTZ order variable for location \(l\) |

### Required constraints

1. Each SKU demand is assigned to exactly one eligible location.
2. A selected location is visited; an unselected location is not visited.
3. Each selected location has one entering and one leaving route arc.
4. The depot has one departure and one return.
5. MTZ constraints eliminate subtours.

The complete equations and declared limitations are in
[`MATHEMATICAL_FORMULATION.md`](../MATHEMATICAL_FORMULATION.md).

## 5. Non-functional requirements

- **Explainability:** display the chosen location for each SKU and the ordered
  visit sequence, not just a distance.
- **Reliability:** validate the dataset and surface solver failures; do not
  display a successful-looking plan when the MIP did not prove optimality.
- **Usability:** one order selector and one route selector; comparison is
  visible without editing source code.
- **Portability:** install dependencies from the project `requirements.txt`;
  use local CSV inputs and run with Streamlit.
- **Performance:** intended for the bundled small dataset and a laptop-scale
  demonstration, not production-scale optimization.

## 6. Interfaces and errors

The only user interface is the local browser page. The command-line MIP entry
point accepts `--order-id`. Invalid order IDs and insufficient whole-SKU stock
produce explicit `ValueError`s; missing HiGHS produces a dependency-specific
`RuntimeError`.
