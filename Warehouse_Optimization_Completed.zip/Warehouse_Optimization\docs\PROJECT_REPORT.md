# Warehouse Picker Route Optimization

**Team members:** Add the four team members' names and contribution summary.  
**Project:** Operations Research final project — single-picker routing with
scattered storage.  
**Research paper:** L. Lücke, K. Heßler, and S. Irnich, “The single picker
routing problem with scattered storage: modeling and evaluation of routing and
storage policies,” *OR Spectrum*, 46, 909–951 (2024).
[https://doi.org/10.1007/s00291-024-00760-4](https://doi.org/10.1007/s00291-024-00760-4)

## AI usage note

AI assistance was used to help implement and test the Python optimization
prototype, organize project documentation, and explain model assumptions. The
team must review the source, run the tests, verify the interpretation of the
paper, and be able to explain every modeling choice before submission. The
synthetic dataset and its results are not results reported by the paper.

## 1. Business Requirements Document

Manual pickers travel to storage locations to fulfil customer orders. The
business question is how storage-location selection and aisle-routing policy
affect travel distance. The prototype accepts one of two sample orders and
compares an assignment-and-routing MIP benchmark with Return, Traversal, and
Largest Gap policies. It reports abstract distance units only; it does not
claim measured labor or cost savings.

The warehouse has five parallel aisles, ten positions per side, 100 storage
locations, a front and rear cross-aisle, and a depot at \((0,0)\). Ten SKUs each
have two stocked locations. One whole SKU demand must be fulfilled from a
single location. One picker handles one order at a time. Congestion, multiple
pickers, capacity, replenishment, and production integration are out of scope.

The workflow is: select sample order → validate stock → solve model and
heuristics → compare distance → inspect location assignment and route. Full
requirements are in [`BRD.md`](BRD.md).

## 2. Software Requirements Specification

The app must accept `ORD001` and `ORD002`, validate the inputs, assign every SKU
to one adequately stocked location, return a depot-to-depot tour for each
strategy, and display distances, selected locations, visit order, and route.
Solver and input errors must be explicit. The detailed functional/data
requirements and validation checks are in [`SRS.md`](SRS.md).

## 3. Technical Design Document

The system reads CSVs, validates them, and runs a Pyomo MIP with HiGHS alongside
three constructive warehouse walks. The MIP minimizes the sum of pairwise
shortest-network distances on the supplied 101-node matrix. Binary variables
select SKU locations, visited locations, and tour arcs; degree and MTZ
constraints enforce a depot cycle. Heuristics enumerate feasible sample
location assignments and build aisle-policy walks. Streamlit and Plotly show
the order, distances, picks, and route.

The MIP is an adapted TSP-style benchmark, not a replication of the paper's
DP/network-flow model. The Largest Gap bridge pass and policy route conventions
are described in [`TDD.md`](TDD.md) and
[`MATHEMATICAL_FORMULATION.md`](../MATHEMATICAL_FORMULATION.md).

## 4. Testing

The automated suite checks data consistency, route coverage and geometry,
optimal MIP termination, MIP-vs-policy benchmark ordering, and insufficient
stock rejection. Run `python -m pytest` from the project directory; run the
interactive smoke test with `python -m streamlit run app.py`. Record execution
date, environment, and results in [`TEST_PLAN.md`](TEST_PLAN.md) after
verification in the final submission environment.

## 5. Prototype and next steps

Start the local prototype with `python -m streamlit run app.py`. The app has not
been hosted. Before final submission, add team names, verify and record test
results, review the model's limitations with the instructor, and rehearse the
walkthrough in [`DEMO_GUIDE.md`](DEMO_GUIDE.md).
