from dataclasses import replace

import pytest

from warehouse_optimizer import (
    POLICIES,
    _path_distance,
    compare_order,
    load_data,
    order_ids,
    solve_heuristic,
    solve_mip,
)


@pytest.fixture(scope="module")
def data():
    return load_data()


def test_source_data_is_consistent(data):
    assert len(data.warehouse) == 100
    assert data.distances.shape == (101, 101)
    assert order_ids(data) == ["ORD001", "ORD002"]
    assert (data.distances.values.diagonal() == 0).all()


@pytest.mark.parametrize("order_id", ["ORD001", "ORD002"])
@pytest.mark.parametrize("policy", POLICIES)
def test_policy_routes_cover_each_selected_location(data, order_id, policy):
    plan = solve_heuristic(order_id, policy, data)
    assert set(plan.visit_order) == set(plan.selected_locations.values())
    assert len(plan.visit_order) == len(set(plan.visit_order))
    assert _path_distance(plan.path) == pytest.approx(plan.distance)
    assert all(
        first[0] == second[0] or first[1] == second[1]
        for first, second in zip(plan.path, plan.path[1:])
    )


@pytest.mark.parametrize("order_id", ["ORD001", "ORD002"])
def test_mip_is_optimal_and_uses_a_feasible_route(data, order_id):
    plan = solve_mip(order_id, data)
    assert plan.optimal
    assert set(plan.visit_order) == set(plan.selected_locations.values())
    assert _path_distance(plan.path) == pytest.approx(plan.distance)
    assert plan.path[0] == (0.0, 0.0)
    assert plan.path[-1] == (0.0, 0.0)


@pytest.mark.parametrize("order_id", ["ORD001", "ORD002"])
def test_mip_benchmarks_all_policy_results(data, order_id):
    plans = compare_order(order_id, data)
    mip = plans[0]
    assert [plan.strategy for plan in plans[1:]] == list(POLICIES)
    assert all(mip.distance <= plan.distance for plan in plans[1:])


def test_rejects_order_demand_without_single_location_supply(data):
    orders = data.orders.copy()
    orders.loc[
        (orders["order_id"] == "ORD001") & (orders["sku_id"] == "SKU01"),
        "demand_qty",
    ] = 100
    invalid_data = replace(data, orders=orders)
    with pytest.raises(ValueError, match="No single location has enough stock"):
        solve_heuristic("ORD001", "Return", invalid_data)


def test_largest_gap_does_not_visit_rear_when_no_rear_picks(data):
    orders = data.orders[
        (data.orders["order_id"] == "ORD001") & (data.orders["sku_id"] == "SKU01")
    ].copy()
    front_only_data = replace(data, orders=orders)
    plan = solve_heuristic("ORD001", "Largest Gap", front_only_data)
    assert max(y for _, y in plan.path) < 11
    assert plan.distance == pytest.approx(10)
