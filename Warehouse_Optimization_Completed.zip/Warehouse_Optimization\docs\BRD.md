# Business Requirements Document (BRD)

## 1. Purpose

Give warehouse supervisors and pickers a small decision-support tool that
compares ways of selecting storage locations and routing one picker for a
customer order. The prototype supports an academic project demonstration; it
does not control a live warehouse.

## 2. Business problem

Manual order picking requires a picker to visit storage locations for several
SKUs. The supplied synthetic dataset gives each of ten SKUs two potential
locations. Choosing a nearby eligible location and a suitable path may reduce
walking compared with an arbitrary pick list. The team needs an explainable
benchmark and a visual prototype to demonstrate this trade-off.

## 3. Objectives and success measures

- Accept either supplied customer order (`ORD001` or `ORD002`).
- Select one sufficiently stocked location for every SKU in the order.
- Return a depot-to-depot route and total distance for an optimal MIP benchmark
  and Return, Traversal, and Largest Gap policies.
- Let a user compare distances and inspect the chosen locations, route, and
  visit sequence in a browser.
- Reject unknown orders and orders that cannot be fulfilled from one location.
- Keep model assumptions and test evidence available to business, development,
  and testing reviewers.

The measure is abstract warehouse travel distance. No labor-time or financial
savings are claimed.

## 4. Stakeholders

| Stakeholder | Need |
|---|---|
| Warehouse supervisor / business reviewer | Understand the recommendation and compare policies |
| Picker | Receive an ordered list of pick locations |
| Developer | Implement the documented model and data contracts |
| Tester | Reproduce feasibility, route, and comparison checks |
| Project team | Explain assumptions and evidence during the review |

## 5. Scope

**Included:** one order at a time; one picker; one complete SKU demand per
eligible location; 100 locations in five parallel aisles; distance comparison;
route visualization; two synthetic sample orders.

**Excluded:** split picks across locations; live WMS integration; dynamic stock
updates; congestion, multiple pickers, travel time, replenishment, capacity,
sequencing by due date, and production deployment.

## 6. User workflow

1. Select an order from the available sample orders.
2. The system validates the order and stock, then solves the MIP and the three
   aisle-policy alternatives.
3. Review the distance comparison.
4. Choose a strategy to display its selected locations, pick list, visit order,
   and warehouse route.
5. Use the mathematical model and test plan to interpret the comparison.

## 7. Business assumptions and constraints

- A location can supply an SKU only when its available quantity meets the full
  order demand for that SKU.
- The picker starts and finishes at the depot \((0,0)\).
- Aisle coordinates and distance units are synthetic; left/right rack faces at
  the same position share a travel path.
- The MIP distance benchmark uses the Phase 3 distance matrix. The three
  heuristic routes follow policy-specific walks on the warehouse layout.
- The exact MIP benchmark is not the research paper's original network-flow
  formulation.

## 8. Acceptance criteria

The prototype is accepted for the demonstration when both supplied orders can
be run, all displayed plans meet demand and return to the depot, the MIP is
reported as optimal only after an optimal solver status, the three heuristic
plans are labeled as heuristics, and the automated tests pass.
