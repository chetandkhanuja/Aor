# Technical Design Document (TDD)

## 1. Architecture

```text
CSV inputs ──> load_data / validation ──> order feasibility
                                      ├─> Pyomo MIP + HiGHS
                                      └─> assignment enumeration + aisle policies
                                                │
                                                v
                               RoutePlan (picks, distance, path, status)
                                                │
                                                v
                                    Streamlit / Plotly prototype
```

`warehouse_optimizer.py` owns input validation, feasible location candidates,
route construction, and model solving. `solve_mip.py` is the command-line MIP
entry point. `app.py` provides order and strategy selectors, a comparison table,
a pick list, and a plotted route. CSV files remain the system of record for this
prototype; no database or external service is required.

## 2. MIP design

For order SKUs \(S\), each \(L_s\) contains only locations whose stock can meet
the complete quantity. Candidate nodes \(N\) are the union of those locations.
Binary \(x_{sl}\) chooses one location; binary \(z_l\) links assignments to
visits; binary \(y_{ij}\) defines the tour. The objective uses Phase 3
shortest-network distances \(d_{ij}\). Incoming/outgoing degree constraints,
one depot departure/return, and MTZ order constraints enforce a single cycle.
Pyomo builds the model and HiGHS must return an optimal termination condition.

For full equations, domains, and limits, see
[`MATHEMATICAL_FORMULATION.md`](../MATHEMATICAL_FORMULATION.md).

## 3. Heuristic design and pseudocode

Each heuristic enumerates the feasible location assignment combinations for the
small sample order, builds a policy-constrained walk, and returns the
lowest-distance assignment for that policy. Enumeration is capped at 4,096
combinations so unsupported larger inputs fail explicitly.

### Return

```text
group selected locations by aisle
for aisles in increasing aisle order:
    enter from front cross-aisle
    visit picks in increasing position order
    return to front cross-aisle
return to depot
```

### Traversal

```text
group selected locations by aisle
for aisles in increasing aisle order:
    traverse from front to rear for even aisle index
    traverse from rear to front for odd aisle index
    visit picks in the direction of travel
if route ends at rear:
    return to front through the nearest aisle line
return to depot
```

### Largest Gap

```text
for each aisle:
    find the largest interval between successive pick positions / aisle ends
    assign picks below that interval to the front sweep
    assign picks above that interval to the rear sweep
service front-sweep picks and return along the front cross-aisle
choose the aisle-line bridge with the shortest route
traverse the bridge aisle to reach the rear cross-aisle
service rear-sweep picks and return to the bridge
traverse the bridge back to the front and return to depot
```

The bridge pass can cross the skipped gap in that aisle; this is a transparent
prototype simplification. These constructive policies and the matrix-based MIP
use different route representations and are not an exact reproduction of the
paper's common state-space implementation.

## 4. Route geometry

Heuristic paths are orthogonal waypoints on front \(y=0\), rear \(y=11\), and
aisle x-coordinates. Their reported length is the Manhattan length of that
physical walk. For MIP route visualization, shortest paths between consecutive
selected nodes are reconstructed on the cross-aisle/aisle network. The MIP's
objective remains the supplied distance-matrix cost.

## 5. Failure handling

Data shape, labels, quantity signs, SKU references, warehouse location
references, and matrix symmetry/diagonal are validated before solving. An order
with no location able to supply a complete SKU demand is rejected. Missing
HiGHS or a non-optimal solver termination raises an error and does not produce a
successful result.

## 6. Deployment

Install `requirements.txt` in a Python environment, then launch with
`python -m streamlit run app.py`. The supplied app is local-only; hosting,
authentication, data upload, and production monitoring are not implemented.
