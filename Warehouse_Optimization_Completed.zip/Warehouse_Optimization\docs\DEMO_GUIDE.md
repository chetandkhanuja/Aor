# Presentation / Prototype Walkthrough

This outline supports the assignment's 15-minute review; no slide deck is
required. Rehearse the model explanation and live app before presenting.

| Time | Segment | Demonstration |
|---|---|---|
| 0:00–2:00 | Business problem | Explain the warehouse, scattered SKU locations, and picker travel objective. |
| 2:00–4:00 | Model | Show the MIP variables, assignment, route, and subtour constraints in the formulation. State the single-location and synthetic-data assumptions. |
| 4:00–6:00 | Testing plan | Show the test cases and report the actual automated test results. |
| 6:00–8:00 | Prototype | Select `ORD001`, compare all strategies, and inspect the MIP route, picks, and warehouse layout. |
| 8:00–10:00 | Second example | Select `ORD002`; compare policy distances and explain changed location choices. |
| 10:00–15:00 | Q&A | Explain the limitations and distinguish this adapted prototype from the paper's exact model. |

Start the app from this project directory with `python -m streamlit run app.py`.
If network or browser access fails, use the same CSV inputs and `python
solve_mip.py --order-id ORD001` for a terminal fallback. Do not claim test
success until the commands have been run.
